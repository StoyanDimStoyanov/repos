create function xpath_exists(text, xml) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
$$;

comment on function xpath_exists(text, xml) is 'test XML value against XPath expression';

alter function xpath_exists(text, xml) owner to postgres;

